## General Instructions

For this project, we are follwoing [this tutorial](https://www.youtube.com/watch?v=iJKCj8uAHz8&t=4185s&ab_channel=freeCodeCamp.org)

Please open @ **1:13:25**
